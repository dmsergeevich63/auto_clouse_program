import os
import subprocess
import sys

def download_dependencies(package_name, destination_folder):
    # Получаем список зависимостей с помощью команды 'pip download'
    try:
        output = subprocess.check_output(['pip', 'download', '--only-binary', ':all:', '--dest', destination_folder, package_name]).decode('utf-8')
        lines = output.strip().split('\n')

        # Проверяем, что файлы зависимостей были скачаны успешно
        for line in lines:
            if line.startswith('Successfully'):
                print(f"\nВсе зависимости загружены в папку: {destination_folder}")
                return

        print("Зависимости не были загружены. Проверьте правильность имени пакета.")

    except subprocess.CalledProcessError as e:
        print(f"Ошибка при поиске или загрузке зависимостей: {e}")
        sys.exit(1)


def generate_install_commands(package_name, destination_folder):
    # Формируем список команд для установки зависимостей
    install_commands = []
    for filename in os.listdir(destination_folder):
        if filename.endswith('.whl'):
            install_commands.append(f"pip install {os.path.join(destination_folder, filename)}")

    # Сохраняем список команд в текстовом файле
    with open(os.path.join(destination_folder, 'install_commands.txt'), 'w') as f:
        f.write('\n'.join(install_commands))

    print(f"Список команд для установки зависимостей сохранен в файле: {os.path.join(destination_folder, 'install_commands.txt')}")


# Запрос имени пакета
package_name = input("Введите имя пакета: ")

# Путь к папке, куда сохранить .whl файлы
destination_folder = './' + package_name

download_dependencies(package_name, destination_folder)
generate_install_commands(package_name, destination_folder)